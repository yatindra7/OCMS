#include <string>
#include <fstream>
#include <iostream>
#include <cstdlib>
using namespace std;

struct operatorNode {
	char data;
	struct operatorNode* next;
};
struct operatorStack {
	int size;
	struct operatorNode* top;
};

struct operatorStack* createStack(){
	struct operatorStack *p;
	p = (struct operatorStack*) malloc(sizeof(operatorStack));
	p -> size = 0;
	p -> top = NULL;
	return p;
}
bool isEmpty(struct operatorStack* stack) {
	return !(stack->size);
}
char peek(struct operatorStack* stack) {
	if (isEmpty(stack)) return -1;
	return (stack->top->data);
}
char pop(struct operatorStack* stack) {
	if (isEmpty(stack)) return -1;
	struct operatorNode* temp = stack->top;
	stack->top = stack->top->next;
	char ans = temp->data;
	free(temp);
	(stack->size) --; 
	return ans;
}
void push(struct operatorStack* stack, char op) {
	struct operatorNode* temp1, *temp2;
	temp1 = (struct operatorNode*) malloc(sizeof(struct operatorNode*));
	temp2 = stack->top;
	temp1->data = op;
	temp1->next = temp2;
	stack->top = temp1;
	(stack -> size) ++;
	return;
}

void printStack(struct operatorStack * stack) {
	if (isEmpty(stack)) return;
	struct operatorNode *p;
	p = stack -> top;
	for (; p; p = p -> next) cout << p -> data << endl;
	return;
}

int isOperand(char *ch) {
	if ((*ch) < 48 || (*ch) > 57) return 0;
	return 1;
}
int operatorPrecedence(char c) {
	if (c == ')') return 3;
	else if (c == '(') return 3;
	else if (c == '*') return 2;
	else if (c == '/') return 2;
	else if (c == '%') return 2;
	else if (c == '+') return 1;
	else if (c == '-') return 1;
	else return -1;
}

int precedence(char op1, char op2) {
	if (operatorPrecedence(op1) >= operatorPrecedence(op2)) return 1;
	return 0;
}

char* convert(const char *exp) {
	struct operatorStack* stack;
	stack = createStack();
	int len = 0;
	for (; *(exp + len); len ++);
	char *r = (char *) malloc(len * sizeof(char));
	char *b = (char *) exp;
	char x;
	int l = 0;
	//cout << exp << endl;
	for (int i = 0; *(exp + i); i ++) {
		//cout << i << endl;
		//cout << "Stack" << ' ';
		//printStack(stack);
		//cout << isEmpty(stack) << endl;
		if (isOperand(b + i)){
			//cout << "heylo" << endl;
			if (i) {
				if (!isOperand(b + i - 1)) {
					r[l] = ' ';
					l ++;
				}
			}
			r[l] = *(exp + i);
			l++;
		}
		else if (!(*(exp + i) == '(') && !(*(exp + i) == ')') && !(*(exp + i) == ' ')) {
			while (!isEmpty(stack) && (precedence(peek(stack), *(exp + i)))) {
				x = peek(stack);
				if (x == '(') break;
				pop(stack);
				r[l] = ' ';
				l ++;
				r[l] = x;
				l ++;
			}
			//cout << "hy" << endl;
			push(stack, *(exp + i));
		}
		else if (*(exp + i) == '(') push(stack, *(exp + i));
		else if (*(exp + i) == ')') {
			while (100) {
				x = pop(stack);
				if (x == '(') break;
				r[l] = ' ';
				l ++;
				r[l] = x;
				l ++;
			}
		}
	}
	//cout << "Printing the string" << endl;
	//cout << r << endl;
	return r;
}

int main() {
	string line;
	ifstream input_file("input.txt");
	ofstream part_1_output_file("20CS30060_A1_P1_output.txt");
	//cout << "here0" << endl;
	if (input_file.is_open()) {
		while (getline(input_file,line)) {
			// First part: Implement convert function and associated linked list impl. of stack 
			//cout << "here" << endl;
			char* rp_exp = convert(line.c_str());
			part_1_output_file << rp_exp << endl;
		}
		input_file.close();
	}
	else cout << "Unable to open file"; 
	part_1_output_file.close();
	return 0;
}