#include <string>
#include <fstream>
#include <iostream>
using namespace std;

struct operatorNode {
	int data;
	struct operatorNode* next;
};
struct operandStack {
	int size;
	struct operatorNode* top;
};

struct operandStack* createStack(){
	struct operandStack *p;
	p = (struct operandStack*) malloc(sizeof(operandStack));
	p -> size = 0;
	p -> top = NULL;
	return p;
}
bool isEmpty(struct operandStack* stack) {
	return !(stack->size);
}
char peek(struct operandStack* stack) {
	if (isEmpty(stack)) return -1;
	return (stack->top->data);
}
int pop(struct operandStack* stack) {
	if (isEmpty(stack)) return -1;
	struct operatorNode* temp = stack->top;
	stack->top = stack->top->next;
	int ans = temp->data;
	free(temp);
	(stack->size) --; 
	return ans;
}
void push(struct operandStack* stack, int op) {
	struct operatorNode* temp1, *temp2;
	temp1 = (struct operatorNode*) malloc(sizeof(struct operatorNode*));
	temp2 = stack->top;
	temp1->data = op;
	temp1->next = temp2;
	stack->top = temp1;
	(stack -> size) ++;
	return;
}

void printStack(struct operandStack * stack) {
	if (isEmpty(stack)) return;
	struct operatorNode *p;
	p = stack -> top;
	for (; p; p = p -> next) cout << p -> data << endl;
	return;
}

int num(char *a, int len) {
	int num = 0, i = len - 1, b = 1, x;
	for (; i > -1; i --) {
		x = a[i] - 48;
		num += b * x;
		b *= 10;
	}
	return num;
}

int isOperand(char *ch) {
	if ((*ch) < 48 || (*ch) > 57) return 0;
	return 1;
}

int calculate(char op, int x1, int x2) {
	if (op == '/') return x2 / x1;
	else if (op == '*') return x1 * x2;
	else if (op == '+') return x2 + x1;
	else if (op == '-') return x2 - x1;
	else return x2 % x1;
}

int evaluate(const char* rp_exp) {
	struct operandStack *stack;
	stack = createStack();
	int i = 0, len = 0, x;
	for (; *(rp_exp + len); len ++);
	char *a = (char *) rp_exp;
	for (; *(a + i);) {
		int flag = i;
		while (a[flag] != ' ') {
			flag ++;
			if (flag == len) break;
		}
		if (isOperand(a + i)) {
			x = num(a + i, flag - i); 
			push(stack, x);
			//cout << i << endl;
		}
		else if ((a[i] == '*') || (a[i] == '/') || (a[i] == '+') || (a[i] == '-') || (a[i] = '%')){
			int x1, x2;
			if(!isEmpty(stack))
			x1 = pop(stack);
			if(!isEmpty(stack))
			x2 = pop(stack);
			int calc = calculate(a[i], x1, x2);
			push(stack, calc);
		}
		i = flag + 1;
		//cout << "Stack: ";
		//printStack(stack);
		//cout << endl;
	}
	int result = pop(stack);
	//cout << rp_exp << endl;
	//cout << result << endl;
	return result;
}

int main() {
	string line;
	ifstream input_file("20CS30060_A1_P1_output.txt");
	ofstream part_2_output_file("20CS30060_A1_P2_output.txt");
	if (input_file.is_open()) {
		while (getline(input_file,line)) {
			// Second part: Implement evaluate function and associated linked list impl. of stack
			part_2_output_file << evaluate(line.c_str()) << endl;
		}
		input_file.close();
	}
	else cout << "Unable to open file"; 
	part_2_output_file.close();
	return 0;
}

